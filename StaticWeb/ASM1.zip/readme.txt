**Nguyen Xuan Thanh (s3915468)**

Static Website (My CV)
There are 4 main pages:
index page:
 Including my profile and can link to the Projects, Contact me and Blog pages
Projects page:
 Including a table of name, link and details of projects I have done
Contact me page:
 Including name, phone number and email input field. Users can send by clicking the "Send" button 
 My contact info will arrange at the very bottom of the page
Blog page:
 Writing about my hobbies, interest in IT, goal and Ideal Job
 A motivation video under the article
*Back buttion appears at the left bottom in every page

Live website URL:https://flamboyant-borg-630be5.netlify.app/index.html
